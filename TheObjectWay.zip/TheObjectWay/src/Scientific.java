
public class Scientific {
	
	public double cosine (double a) {
		return Math.cos(a);
	}

	public double sin (double a) {
		return Math.sin(a);
	}
	
	public double tan (double a) {
		return Math.tan(a);
	}
	
	}

